/**
 * 
 */
/**
 * @author asus
 *
 */
module StudentGradeCalculator {
}